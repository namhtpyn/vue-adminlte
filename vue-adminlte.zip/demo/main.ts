import Vue from 'vue'
import App from './App.vue'
import NDataTable from '../component/NDataTable.vue'

if (process.env.NODE_ENV === 'development') {
  new Vue({
    el: '#app',
    render: h => h(App)
  })
}
export default NDataTable
