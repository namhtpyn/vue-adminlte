<template>
  <div class="box">
    <div class="box-header">
      <h3 class="box-title">{{caption}}</h3>

      <div class="box-tools">
        <div v-if="enableSearch" class="input-group input-group-sm hidden-xs" style="width: 250px;">
          <input
            type="text"
            name="table_search"
            class="form-control pull-right"
            v-model="nSearch"
            placeholder="Tìm kiếm"
          />

          <div class="input-group-btn">
            <button type="submit" class="btn btn-default">
              <i class="fa fa-search"></i>
            </button>
          </div>
        </div>
      </div>
    </div>
    <div class="box-body">
      <table class="table table-bordered">
        <slot name="head" :headers="headers">
          <thead>
            <tr v-for="level in cHeaderRowCount" :key="level">
              <th
                v-for="(header,index) in getHeaderLevel(level)"
                :key="index"
                @click="sort(header.value)"
                :colspan="header.children ? getHeaders(header.children).length: 1"
                :rowspan="header.children ? 1: cHeaderRowCount"
                :class="{
                'sortable': true,
                'asc': (nSortObject.field===header.value && nSortObject.asc),
                'desc': (nSortObject.field===header.value && !nSortObject.asc),
              }"
              >{{header.text}}</th>
            </tr>
          </thead>
        </slot>
        <tbody>
          <tr v-for="(row,rowIndex) in cItemsInPage" :key="rowIndex">
            <td v-for="(col,colIndex) in cHeaders" :key="colIndex">
              <slot :name="`item.${col.value}`" :item="row">{{ row[col.value] }}</slot>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
    <div class="box-footer clearfix">
      <nav style="width:100%;">
        <div
          class="summary hidden-xs form-inline form-group form-group-sm pull-left"
          style="display:inline-block"
        >
          <div
            class="form-control-static"
          >Trang {{ nCurrentPage }}/{{ cTotalPages}} ({{ items.length}} mục)</div>
        </div>
        <ul class="pagination pagination-sm no-margin pull-left">
          <li :class="{'disabled': nCurrentPage===1}">
            <a href="#" @click="previousPageClick">«</a>
          </li>
          <li>
            <!-- <a href="#" class="hidden-xs">1</a> -->
            <select
              @change="pageChange"
              class="hidden-xs form-control pull-left"
              style="width:60px;display: inline-block; height:30px; padding: 6px 6px"
            >
              <option v-for="(p,i) in cTotalPages" :key="i" :value="p">{{p}}</option>
            </select>
          </li>

          <li :class="{'disabled': nCurrentPage===cTotalPages}">
            <a href="#" @click="nextPageClick">»</a>
          </li>
        </ul>
        <select
          @change="itemPerPageChange"
          class="form-control pull-right"
          style="width:70px;display: inline-block; height:30px;  padding: 6px 6px"
        >
          <option value="5">5</option>
          <option value="10">10</option>
          <option value="25">25</option>
          <option value="50">50</option>
          <option value="100">100</option>
        </select>

        <!-- <div class="summary hidden-xs form-inline form-group form-group-sm">
          <div class="form-control-static">Trang 1/15 (143 mục)</div>
          <li class="pagination pagination-sm">
            <li class="disabled">
              <a>
                <span class="image glyphicon glyphicon-chevron-left"></span>
              </a>
            </li>
            <li class="active page-number hidden-xs">
              <a data-args href="javascript:;">1</a>
            </li>
            <li class="page-number hidden-xs">
              <a data-args="PN1" href="javascript:;">2</a>
            </li>
            <li class="page-number hidden-xs">
              <a data-args="PN2" href="javascript:;">3</a>
            </li>
            <li class="page-number hidden-xs">
              <a data-args="PN3" href="javascript:;">4</a>
            </li>
            <li class="page-number hidden-xs">
              <a data-args="PN4" href="javascript:;">5</a>
            </li>
            <li class="page-number hidden-xs">
              <a data-args="PN5" href="javascript:;">6</a>
            </li>
            <li class="page-number hidden-xs">
              <a data-args="PN6" href="javascript:;">7</a>
            </li>
            <li class="disabled ellipsis hidden-xs">
              <span>…</span>
            </li>
            <li class="page-number hidden-xs">
              <a data-args="PN12" href="javascript:;">13</a>
            </li>
            <li class="page-number hidden-xs">
              <a data-args="PN13" href="javascript:;">14</a>
            </li>
            <li class="page-number hidden-xs">
              <a data-args="PN14" href="javascript:;">15</a>
            </li>
            <li>
              <a data-args="PBN" href="javascript:;">
                <span class="image glyphicon glyphicon-chevron-right"></span>
              </a>
            </li>
          </li>
        </div>-->
      </nav>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Prop, PropSync } from "vue-property-decorator";
@Component({})
export default class NDataTable extends Vue {
  @Prop(Array) headers!: any[];
  @Prop(Array) items!: any[];
  @Prop(String) caption!: string;
  @Prop({ type: Boolean, default: false }) enableSearch!: boolean;
  nCurrentPage = 1;
  nItemPerPage: number = 5;
  nSortObject = { field: "", asc: true };
  nSearch = "";

  get cItemsInPage() {
    let items = this.items.slice();
    if (this.nSearch !== "")
      items = items.filter(o =>
        Object.values(o).some(v =>
          v
            .toString()
            .toUpperCase()
            .includes(this.nSearch.toUpperCase())
        )
      );
    if (this.nSortObject.field !== "")
      items = items.sort(this.compare).map(o => o);
    return items.slice(
      (this.nCurrentPage - 1) * this.nItemPerPage,
      this.nCurrentPage * this.nItemPerPage
    );
  }
  get cTotalPages() {
    return Math.ceil(this.items.length / this.nItemPerPage);
  }
  sort(field: string) {
    if (this.nSortObject.field !== field) {
      this.nSortObject.field = field;
      this.nSortObject.asc = true;
    } else if (this.nSortObject.asc) {
      this.nSortObject.asc = false;
    } else {
      this.nSortObject.field = "";
    }
  }

  previousPageClick() {
    if (this.nCurrentPage >= 2) this.nCurrentPage--;
  }
  nextPageClick() {
    if (this.nCurrentPage < this.cTotalPages) this.nCurrentPage++;
  }
  itemPerPageChange(e: any) {
    this.nItemPerPage = Number(e.target.value);
    this.nCurrentPage = 1;
  }
  pageChange(e: any) {
    this.nCurrentPage = Number(e.target.value);
  }

  get cHeaderRowCount() {
    return this.getDepth(this.headers);
  }
  get cHeaders() {
    return this.getHeaders(this.headers);
  }
  getHeaderLevel(level: number) {
    return this.getLevel(this.headers, level);
  }
  getLevel(array: any, level = 1) {
    let ar = array;
    for (let i = 1; i < level; i++)
      ar = ar
        .filter((a: any) => a.hasOwnProperty("children"))
        .flatMap((a: any) => a.children);
    return ar;
  }
  getHeaders(array: any) {
    let save: any[] = []; //array.filter((o: any) => !o.hasOwnProperty("children"));
    array.forEach((item: any) => {
      if (!item.hasOwnProperty("children")) save.push(item);

      if (typeof item.children === "object")
        save = save.concat(this.getHeaders(item.children));
    });
    return save;
  }
  getDepth(array: any) {
    var level = 1;
    array.forEach((item: any) => {
      if (!item.hasOwnProperty("children")) return;

      if (typeof item.children === "object") {
        var depth = this.getDepth(item.children) + 1;
        level = Math.max(depth, level);
      }
    });
    return level;
  }
  compare(a: any, b: any) {
    if (this.nSortObject.field === "") return 0;

    const genreA = a[this.nSortObject.field];
    const genreB = b[this.nSortObject.field];

    let comparison = 0;
    if (genreA > genreB) {
      comparison = this.nSortObject.asc ? 1 : -1;
    } else if (genreA < genreB) {
      comparison = this.nSortObject.asc ? -1 : 1;
    }
    return comparison;
  }
}
</script>

<style scoped>
.table thead .sortable {
  cursor: pointer;
}
.table thead .sortable.asc:after {
  content: "↓";
}
.table thead .sortable.desc:after {
  content: "↑";
}
</style>